// Server bootstrap app.js
require('dotenv').config();
const express = require('express');
const session = require('express-session');
const flash   = require('connect-flash');
const passport= require('passport');
const ejsLayouts = require('express-ejs-layouts');
const path = require('path'); // <--- Add this
const lusca = require('lusca');

require('./config/passport')(passport);           // ➜ configure strategy

const app = express();

// --- view engine
app.set('view engine', 'ejs');
app.set('views', __dirname + '/views');
app.use(ejsLayouts);
app.set('layout', 'layouts/main'); // Explicitly set the default layout

// --- body parsing
app.use(express.urlencoded({ extended: false }));
app.use(express.json()); // For parsing application/json API request bodies

// --- sessions
app.use(session({
  secret            : process.env.SESSION_SECRET,
  resave            : false,
  saveUninitialized : false,
  cookie            : {
    maxAge: 1000 * 60 * 60, // 1h
    sameSite: 'Lax', // Explicitly set SameSite policy
    secure: process.env.NODE_ENV === 'production' // Set to true only in production (if using HTTPS)
  }
}));

// --- passport
app.use(passport.initialize());
app.use(passport.session());
app.use((req, res, next) => {
  res.locals.user = req.user;
  next();
});
app.use(flash());

// --- CSRF protection with lusca
// Apply CSRF protection globally. This should be after session and body-parser.
// For specific routes, you can apply it selectively in the router.
// However, for general safety with forms, global is often a good start.
app.use(lusca.csrf()); // Default configuration uses session-based tokens

// Middleware to make CSRF token available to all views
app.use((req, res, next) => {
  if (req.csrfToken) { // Lusca should add this function to the request
    const token = req.csrfToken(); // Get the token
    console.log('CSRF Token Generated for res.locals:', token); // Log the token
    res.locals._csrf = token; // Set it in locals
  } else {
    console.log('req.csrfToken function NOT FOUND on request object for res.locals middleware');
  }
  next();
});

// --- static assets (css, logos, etc.)
app.use(express.static(__dirname + '/public'));

// --- flash middleware: expose to all templates
app.use((req,res,next)=>{
  res.locals.success = req.flash('success');
  res.locals.error   = req.flash('error');
  next();
});

// Serve the logo specifically
app.get('/dhl-logo.svg', (req, res) => {
  res.sendFile(path.join(__dirname, 'views', 'layouts', 'dhl-logo.svg'));
});

// --- Authentication Middleware for Web Pages ---
const ensureWebAuthenticated = (req, res, next) => {
  if (req.isAuthenticated()) {
    return next();
  }
  req.session.returnTo = req.originalUrl; // Store the original URL
  console.log(`[ensureWebAuthenticated] Set req.session.returnTo to: ${req.session.returnTo}. Full session: ${JSON.stringify(req.session)}`);
  req.flash('error', 'Please log in to view that resource.');
  res.redirect('/login-page');
};

// --- Specific route for Supervisor Validation page ---
// This ensures that any path like /app/validate-checklist/someID serves the validate-checklist.html file.
// The ensureWebAuthenticated middleware protects it.
app.get('/app/validate-checklist/:id', ensureWebAuthenticated, (req, res) => {
    res.sendFile(path.join(__dirname, '..', 'Public', 'validate-checklist.html'));
});

// --- Serve SanitationChecks Application (Protected) ---
// This serves static files from the main 'Public' directory under the '/app' path for other /app/* routes.
// Access is protected by ensureWebAuthenticated.
// This should come AFTER specific /app/ routes like the one above.

// ADDED: Logging for /app requests to test if HTML files are being requested
app.use('/app', (req, res, next) => {
  console.log(`[App Static Middleware] Received request for: ${req.method} ${req.originalUrl}`);
  if (req.originalUrl.endsWith('.html')) {
    console.log(`[App Static Middleware] Attempting to serve HTML file: ${req.originalUrl}. User authenticated: ${req.isAuthenticated()}`);
  }
  next();
});
// END ADDED

app.use('/app', ensureWebAuthenticated, express.static(path.join(__dirname, '..', 'Public')));


// --- routes
// --- Web Page Routes ---
app.get('/', (req, res) => {
  res.redirect('/login-page');
});

app.get('/login-page', (req, res) => {
  console.log(`[GET /login-page] Arrived at login page. req.session content: ${JSON.stringify(req.session)}`);
  // Ensure 'login' is the correct name of your EJS template for the login page
  res.render('login', { title: 'Login', user: req.user });
});

app.post('/login-page', (req, res, next) => {
  console.log('[Login POST Start] req.session before passport.authenticate:', JSON.stringify(req.session));
  passport.authenticate('local', (err, user, info) => {
    console.log('[Login POST passport.authenticate callback] req.session:', JSON.stringify(req.session));
    if (err) { return next(err); }
    if (!user) {
      req.flash('error', info.message || 'Login failed. Please try again.');
      return res.redirect('/login-page');
    }

    // Capture returnTo BEFORE req.logIn, as req.logIn might regenerate the session
    const capturedReturnTo = req.session.returnTo;
    console.log(`[Login POST passport.authenticate callback] Captured req.session.returnTo before req.logIn: ${capturedReturnTo}`);

    req.logIn(user, (err) => {
      if (err) { return next(err); }
      // req.session might have been regenerated by req.logIn(), so req.session.returnTo might be gone.
      // Use the capturedReturnTo value.
      console.log(`[Login POST req.logIn callback] req.session AFTER req.logIn:`, JSON.stringify(req.session));
      console.log(`[Login POST req.logIn callback] Using capturedReturnTo: ${capturedReturnTo}`);
      
      // It's good practice to delete the original if it somehow survived, though unlikely here.
      if (req.session && req.session.returnTo) {
          delete req.session.returnTo;
      }

      console.log(`[Login POST req.logIn callback] Redirecting to: ${capturedReturnTo || '/dashboard'}`);
      return res.redirect(capturedReturnTo || '/dashboard');
    });
  })(req, res, next);
});

app.get('/logout-page', (req, res, next) => {
  req.logout((err) => {
    if (err) {
      return next(err);
    }
    req.flash('success', 'You have successfully logged out.');
    res.redirect('/login-page');
  });
});

// --- Dashboard Route ---
app.get('/dashboard', ensureWebAuthenticated, (req, res) => {
  // req.user is populated by Passport and made available to templates
  // by the middleware at line 36 (res.locals.user = req.user)
  res.render('dashboard', {
    title: 'Dashboard'
    // The 'user' object will be available in dashboard.ejs via res.locals.user
  });
});

// --- API Routes ---
app.use('/api/auth', require('./routes/auth')); // Mount API auth routes

// --- Admin Routes ---
app.use('/admin', require('./routes/admin')); // Mount Admin routes

// --- Other Protected Routes ---
app.use('/checklists', require('./routes/checklist')); // protected

// --- start server
const PORT = process.env.PORT || 3000;
app.listen(PORT, ()=> console.log(`Server running on http://localhost:${PORT}`));