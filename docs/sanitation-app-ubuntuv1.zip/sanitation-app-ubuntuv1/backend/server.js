console.log("[Debug] server.js: Server starting with latest code...");
require('dotenv').config(); // Ensure this is at the very top

const express = require('express');
const bodyParser = require('body-parser');
const passport = require('passport');
const { Strategy: JwtStrategy, ExtractJwt } = require('passport-jwt');

const cors = require('cors');
const path = require('path');
const fs = require('fs');  // Import the file system module


const nodemailer = require('nodemailer');  // Import nodemailer for sending emails

const app = express();
const port = process.env.PORT || 3001; // Use environment variable for port

// --- JWT Authentication Setup ---
const jwtOptions = {
  jwtFromRequest: ExtractJwt.fromAuthHeaderAsBearerToken(),
  secretOrKey: process.env.JWT_SECRET, // Ensure JWT_SECRET is in backend/.env
};

passport.use(new JwtStrategy(jwtOptions, (jwt_payload, done) => {
  // jwt_payload will contain { userId, username } from the token
  // We trust the dhl_login server as the issuer. No need to re-query User DB here.
  // The 'user' object for protected routes will be the jwt_payload.
  if (jwt_payload && jwt_payload.userId) {
    return done(null, jwt_payload); // Pass the payload as req.user
  } else {
    return done(null, false, { message: 'Invalid token payload.' });
  }
}));

// Middleware
app.use(passport.initialize()); // Initialize Passport
app.use(bodyParser.json());
app.use(bodyParser.urlencoded({ extended: true }));
app.use(cors());
app.use((req, res, next) => {
    res.header('Access-Control-Allow-Origin', '*'); // Allow requests from all origins
    res.header('Access-Control-Allow-Methods', 'GET, POST, PUT, DELETE');
    res.header('Access-Control-Allow-Headers', 'Content-Type, Authorization');
    next();
});
// Serve static files
console.log('Registering static file middleware...');
app.use(express.static(path.join(__dirname, '../Public')));
console.log('Serving static files from:', path.join(__dirname, '../Public'));


// Directory where data will be stored
const dataDir = path.join(__dirname, 'data');

// Helper function to select 20% of the checkboxes
function getRandomCheckboxes(checkboxesByHeading) {
    const headingKeys = Object.keys(checkboxesByHeading);
    const candidateCheckboxIds = [];

    // Step 1: Collect all itemIDs from under the headings
    for (const heading in checkboxesByHeading) {
        if (Object.hasOwnProperty.call(checkboxesByHeading, heading)) {
            const itemsUnderHeading = checkboxesByHeading[heading];
            if (typeof itemsUnderHeading === 'object' && itemsUnderHeading !== null) {
                for (const itemId in itemsUnderHeading) {
                    if (Object.hasOwnProperty.call(itemsUnderHeading, itemId)) {
                        candidateCheckboxIds.push(itemId);
                    }
                }
            }
        }
    }

    // Step 2: Filter out any candidate ID that is also a heading key
    const eligibleCheckboxIds = candidateCheckboxIds.filter(id => !headingKeys.includes(id));

    if (eligibleCheckboxIds.length === 0) {
        return []; // No eligible checkboxes to select from
    }

    const totalEligibleCheckboxes = eligibleCheckboxIds.length;
    // Ensure selectedCount is at least 1 if there are eligible checkboxes, but not more than available.
    let selectedCount = Math.ceil(totalEligibleCheckboxes * 0.20);
    selectedCount = Math.max(1, selectedCount); // Select at least 1 if possible
    selectedCount = Math.min(selectedCount, totalEligibleCheckboxes); // Don't try to select more than available


    // Fisher-Yates shuffle to get a random selection without duplicates
    const shuffledIds = [...eligibleCheckboxIds];
    for (let i = shuffledIds.length - 1; i > 0; i--) {
        const j = Math.floor(Math.random() * (i + 1));
        [shuffledIds[i], shuffledIds[j]] = [shuffledIds[j], shuffledIds[i]];
    }

    return shuffledIds.slice(0, selectedCount);
}

// Function to save data to a file
function saveDataToFile(data, filePath) {
    if (!fs.existsSync(dataDir)) {
        fs.mkdirSync(dataDir, { recursive: true });
    }

    // Save form data to a file using the provided filePath
    fs.writeFile(filePath, JSON.stringify(data, null, 2), (err) => {
        if (err) {
            console.error('Error writing file:', err);
        } else {
            console.log(`Data saved to ${filePath}`);
        }
    });
}

// Endpoint to handle form submissions
// Define authenticateApi middleware for protecting routes
const authenticateApi = passport.authenticate('jwt', { session: false });

app.post('/submit-form', authenticateApi, (req, res) => {
    const formData = req.body;


    console.log('Received Data:', formData);

    if (!formData.title) {
        return res.status(400).json({ error: "Page title is missing from the submission." });
    }

    if (!formData.checkboxes || typeof formData.checkboxes !== 'object') {
        return res.status(400).json({ error: "Checkboxes data is missing or invalid." });
    }

    const supervisorEmail = formData.supervisorEmail;

    // Validate supervisorEmail
    if (!supervisorEmail) {
        return res.status(400).json({ error: 'Supervisor email is required' });
    }

    // Generate a single timestamp for both the file name and the email link
    const timestamp = Date.now();
    const filename = `data_${timestamp}.json`;

    // Get random 20% checkboxes
    const randomCheckboxes = getRandomCheckboxes(formData.checkboxes);

    // Add randomCheckboxes to formData
    formData.randomCheckboxes = randomCheckboxes;

    // Save the modified formData (including randomCheckboxes) to a file
    const filePath = path.join(dataDir, filename);
    saveDataToFile(formData, filePath);

    // Send an email to the supervisor with the same timestamp in the checklist link
    // BASE_URL should point to the dhl_login server (e.g., http://localhost:3000)
    const baseUrl = process.env.BASE_URL || `http://localhost:3000`;
    const checklistUrl = `${baseUrl}/app/validate-checklist/${timestamp}`; // Link to UI served by dhl_login


    // Pass formData.title as the checklistTitle
    sendEmailToSupervisor(supervisorEmail, checklistUrl, filename, formData.title, (emailError) => {
        if (emailError) {
            console.error('Failed to send email:', emailError);
            return res.status(500).json({ error: 'Failed to send email. Please try again.' });
        }

        // If everything is successful, send a success response
        res.status(200).json({ message: 'Form submitted and email sent!' });
    });
});

// Send an email to the supervisor with a checklist link, filename, and title
function sendEmailToSupervisor(supervisorEmail, checklistUrl, filename, checklistTitle, callback) {
    const transporter = nodemailer.createTransport({
        service: 'gmail',
        auth: {
            user: process.env.EMAIL_USER,
            pass: process.env.EMAIL_PASS
        }
    });

    const mailOptions = {
        from: process.env.EMAIL_USER,
        to: supervisorEmail,
        subject: `Sanitation Checklist for Review: ${checklistTitle}`, // Add title to subject
        html: `<p>A new checklist "<b>${checklistTitle}</b>" (Filename: ${filename}) requires your validation. Click <a href="${checklistUrl}">here</a> to review.</p>` // Add title and filename to body, make link text "here"
    };

    transporter.sendMail(mailOptions, (error, info) => {
        if (error) {
            console.error('Failed to send email:', error);
            return callback(error);
        } else {
            console.log('Email sent: ' + info.response);////////////////////
            return callback(null);
        }
    });
}

// Route to handle GET /validate/:id (load the validation page)
app.get('/validate/:id', authenticateApi, (req, res) => {
    console.log(`[Debug] GET /validate/:id - START - ID: ${req.params.id}`);
    const fileId = req.params.id;  // Get the unique ID from the URL (timestamp)

    // Construct the file path based on the ID
    const filePath = path.join(dataDir, `data_${fileId}.json`);

    // Check if the file exists
    if (fs.existsSync(filePath)) {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const formData = JSON.parse(fileData);

        // Check if randomCheckboxes is available and is an array
        if (!formData.randomCheckboxes || !Array.isArray(formData.randomCheckboxes)) {
            return res.status(400).json({ message: 'Random checkboxes not found in the checklist data.' });
        }

        // Send the relevant parts of formData as JSON
        // The client-side (validate-checklist.html) will handle rendering.
        res.status(200).json({
            fileId: fileId,
            title: formData.title,
            // The full checkboxes object is needed for the client to find labels/headings
            checkboxes: formData.checkboxes,
            randomCheckboxes: formData.randomCheckboxes
            // We don't need to send supervisorValidation here, as this is for initial load.
        });

    } else {
        // If the file does not exist, send a 404 error as JSON
        res.status(404).json({ message: 'Checklist not found.' });
    }
    console.log(`[Debug] GET /validate/:id - END - ID: ${req.params.id}`);
});


// POST route to handle supervisor validation form submission
app.post('/validate/:id', authenticateApi, (req, res) => {
    console.log(`[Debug] POST /validate/:id - START - ID: ${req.params.id}`);
    const fileId = req.params.id;
    const validationData = req.body;

    // Read the original checklist data
    const filePath = path.join(dataDir, `data_${fileId}.json`);
    if (!fs.existsSync(filePath)) {
        return res.status(404).json({ message: 'Checklist not found.' });
    }
    // Read the original checklist data from the file
    const fileData = fs.readFileSync(filePath, 'utf8');
    const formData = JSON.parse(fileData);

    // Update checkboxes based on the validation data (both checked and unchecked)
    validationData.validatedCheckboxes.forEach((validatedCb) => {
        const { id: validatedId, checked: newCheckedState } = validatedCb;
        let itemUpdated = false;
        // Iterate through headings to find the validated checkbox ID
        for (const headingKey in formData.checkboxes) {
            if (formData.checkboxes[headingKey] && formData.checkboxes[headingKey][validatedId]) {
                // Update the 'checked' status of the specific checkbox item
                formData.checkboxes[headingKey][validatedId].checked = newCheckedState;
                itemUpdated = true;
                break; // Found and updated, no need to check other headings for this ID
            }
        }
        if (!itemUpdated) {
            console.warn(`Validated checkbox ID ${validatedId} not found in original checklist data under any heading.`);
        }
    });

    // Add supervisor feedback to the formData
    formData.supervisorValidation = {
        supervisorName: validationData.supervisorName,
        validatedCheckboxes: validationData.validatedCheckboxes.reduce((acc, cb) => {
            acc[cb.id] = cb.checked;
            return acc;
        }, {})
    };

    // Save the updated checklist data back to the file
    fs.writeFileSync(filePath, JSON.stringify(formData, null, 2));

    res.status(200).json({ message: 'Validation completed successfully.' });
    console.log(`[Debug] POST /validate/:id - END - ID: ${req.params.id}`);
});

// Endpoint to view the checklist data in the browser
app.get('/view-checklist/:id', authenticateApi, (req, res) => {
    const fileId = req.params.id;  // Get the unique ID from the URL (timestamp)

    // Construct the file path based on the ID
    const filePath = path.join(dataDir, `data_${fileId}.json`);

    // Check if the file exists
    if (fs.existsSync(filePath)) {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const formData = JSON.parse(fileData);

        // Send the formData as JSON response
        res.json(formData);
    } else {
        // If the file does not exist, send a 404 error
        res.status(404).send('Checklist not found.');
    }
});

// Endpoint to view the checklist data in a readable HTML format
app.get('/view-checklist-html/:id', authenticateApi, (req, res) => {
    const fileId = req.params.id;  // Get the unique ID from the URL (timestamp)

    // Construct the file path based on the ID
    const filePath = path.join(dataDir, `data_${fileId}.json`);

    // Check if the file exists
    if (fs.existsSync(filePath)) {
        const fileData = fs.readFileSync(filePath, 'utf8');
        const formData = JSON.parse(fileData);

        // Create an HTML response
        let htmlContent = `
            <html>
                <head>
                    <title>Checklist Data</title>
                </head>
                <body>
                    <h1>Checklist Data for ${fileId}</h1>
                    <pre>${JSON.stringify(formData, null, 2)}</pre>
                </body>
            </html>
        `;

        res.send(htmlContent);
    } else {
        // If the file does not exist, send a 404 error
        res.status(404).send('Checklist not found.');
    }
});



// Start the server
console.log('Attempting to start server...');
const server = app.listen(port, '0.0.0.0', () => { // Use the port variable
    console.log('Backend API Server listener callback executed.');
    console.log(`Backend API Server is running on http://localhost:${port}`);
});

server.on('error', (error) => {
    if (error.syscall !== 'listen') {
        throw error;
    }

    const bind = typeof port === 'string'
        ? 'Pipe ' + port
        : 'Port ' + port;

    // handle specific listen errors with friendly messages
    switch (error.code) {
        case 'EACCES':
            console.error(`[FATAL] ${bind} requires elevated privileges`);
            process.exit(1);
            break;
        case 'EADDRINUSE':
            console.error(`[FATAL] ${bind} is already in use. Is another instance of the backend or another application using this port?`);
            process.exit(1);
            break;
        default:
            console.error(`[FATAL] Server startup error: ${error.code}`, error);
            throw error;
    }
});

//app.listen(port, () => {
//    console.log(`Server is running on http://localhost:${port}`);
//});

